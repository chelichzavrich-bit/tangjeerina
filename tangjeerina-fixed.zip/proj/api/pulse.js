// Точка входа /api/pulse. Вся логика лежит в lib/pulse.js.
// (Раньше здесь был старый дубликат с неверными путями require - он ломал и «пульс», и голосовые.)
const { handlePulseRequest } = require('../lib/pulse');

module.exports = (req, res) => handlePulseRequest(req, res);
