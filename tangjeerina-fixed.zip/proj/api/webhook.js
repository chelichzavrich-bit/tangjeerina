// Telegram webhook: Танг Джи Рина (Vercel + Google Gemini).
// Логика разложена по модулям в папке lib/. Текст персонажа лежит в lib/persona.js (его трогать не нужно).
//
// Как бот решает, отвечать ли (в группах):
//   ВСЕГДА отвечает: упоминание @бота, ответ на её сообщение, команда, обращение по имени (Танг/Танджи), личка.
//   ИНОГДА (с шансом, кулдауном и лимитом в час): лор-слова без пинга, ссылки, фото, новички, просто так.
//   В любом случае ВСЕ сообщения чата попадают в память - поэтому она видит контекст беседы.
const { cfg } = require('../lib/config');
const memory = require('../lib/memory');
const { telegram, sendMessage, getMe, downloadFile } = require('../lib/telegram');
const { readIncoming, pickAttachment } = require('../lib/files');
const { extractUrls, parseLinks, describeLinks } = require('../lib/links');
const { generateReply, buildContents } = require('../lib/ai');
const { randomFallback } = require('../lib/fallbacks');
const { handlePulseRequest } = require('../lib/pulse');
const { getCryptoData, getPairData, PAIRS, PAIR_ALIASES } = require('../lib/market');
const ctx = require('../lib/context');

const HOUR = 3600000;

function parseBody(req) {
    if (typeof req.body === 'string') {
        try { return JSON.parse(req.body); } catch (_) { return null; }
    }
    return req.body || null;
}

const displayName = (from) => (from && (from.first_name || from.username)) || 'Аноним';
const rnd = (a) => a[Math.floor(Math.random() * a.length)];
const isGroupChat = (chat) => chat.type === 'group' || chat.type === 'supergroup';

// ═══════════════════════════════════════════════════════════════
// Рыночные данные: шутки и инструкция
// ═══════════════════════════════════════════════════════════════
const GENERIC_ANGLES = [
    'Сравни эти цифры с длиной веток Жака, его тупостью или тем, сколько мандаринов ты украсть за один звонок.',
    'Скажи, что эта сумма меньше, чем ты найти в кармане у лошка, или что твой оффшорный счёт с краденым весит больше.',
    'Назови эту валюту фантиком из ЛНР или мусором, который даже бомж не подобрать, и посмейся над тем, кто её держит.',
    'Скажи, что разница в курсе или само число меньше, чем IQ собеседника, и предложи ему идти работать за копейки.',
    'Обыграй это число через абсурд: например, что за такие деньги можно купить только дырку от бублика в вахтёрской.'
];
const FIAT_ANGLES = [
    'Сравни этот курс с "длина см Жака, когда он рад меня видеть" или тем, сколько мандаринов ты украсть за один звонок.',
    'Скажи, что эта сумма меньше, "чем твой шансы вылазить из мамкин подвала, поздравляю", или что твой оффшорный счёт с краденым весит больше.',
    'Назови эту валюту фантиком из ЛНР или мусором, который даже бомж не подобрать, и посмейся над тем, кто её держит.',
    'Скажи, что разница в курсе или само число меньше, чем IQ собеседника, и предложи ему идти работать за копейки или лизать ей пятки бесплатно.',
    'Обыграй это число через абсурд: например, что за такие деньги можно купить только дырку от бублика в вахтёрской.'
];
const CRYPTO_ANGLES = [
    'Похвастайся, что твой украденный портфель в плюсе, а этот курс смешон по сравнению с тем, что ты украла.',
    'Злорадствуй или радуйся, но обязательно упомяни, что традиционные финансы горят, а ты сидишь в оффшоре.',
    'Сравни цену этой монеты с чем-то абсурдным из лора (вахтёрская, мандарины, ветки Жака).',
    'Назови инвесторов лохами, которые кормят твой будущий ужин своими потерями или прибылью.',
    'Скажи, что за такие деньги можно купить только воздух в ЛНР, но ты всё равно богаче.'
];

function marketBlock(type, data, angles) {
    return `[СВЕЖИЕ ДАННЫЕ РЫНКА (${type}): ${data}]. ИНСТРУКЦИЯ ДЛЯ ТАНГ: ${rnd(angles)} ЗАПРЕЩЕНО: давать финансовые советы, писать как ИИ-ассистент, использовать фразы "мой оффшор плакать", "твои бумажки обесцениться" или "чудесно что мне есть поевать" (придумай НОВУЮ уникальную шутку). Говори ломаным русским, используй "мочь", НЕ ПЕРЕПИСЫВАЙ данные сухим списком, а вплети числа словами (например: "девяносто два с копейками"). Используй ТОЛЬКО эмодзи: ☺️ 🤗 😋 🤭 🫣. Ответ: 1-3 предложения.`;
}

// /kurs, /crypto (с аргументом или без). Команды, адресованные другому боту (/kurs@other_bot), пропускаются.
function parseMarketCommand(userText, botUsername) {
    const match = userText.match(/^\/(kurs|crypto)(?:@(\w+))?\s*(.+)?$/i);
    if (!match) return null;
    if (match[2] && botUsername && match[2].toLowerCase() !== botUsername.toLowerCase()) return null;
    return { command: match[1].toLowerCase(), arg: match[3] ? match[3].trim().toLowerCase() : null };
}

async function handleCallbackQuery(callbackQuery) {
    const data = callbackQuery.data || '';
    const chatId = callbackQuery.message && callbackQuery.message.chat && callbackQuery.message.chat.id;
    try {
        await telegram('answerCallbackQuery', { callback_query_id: callbackQuery.id });
    } catch (e) {
        console.error('answerCallbackQuery error:', e.message);
    }
    if (!chatId) return;

    const [type, arg] = data.split(':');
    let replyText = '';
    let histNote = '';

    if (type === 'kurs' && PAIRS[arg]) {
        const pair = PAIRS[arg];
        const rate = await getPairData(pair.from, pair.to);
        histNote = `[нажал кнопку: курс ${pair.label}]`;
        try {
            const history = await memory.getHistory(chatId);
            const contents = buildContents(history, [{ text: marketBlock('ФИАТ', rate, FIAT_ANGLES) }]);
            replyText = (await generateReply(contents, { userLen: 100, deadline: Date.now() + 20000 })).text;
        } catch (e) {
            console.error('Market reply generation error:', e.message);
            replyText = 'Мой идеальный компьютер сломать этот курс, но ты всё равно лох, раз спрашивать у меня 🤭';
        }
    } else if (type === 'crypto') {
        const coins = arg ? arg.split('+') : ['bitcoin', 'ethereum'];
        const rate = await getCryptoData(coins);
        histNote = `[нажал кнопку: крипта ${coins.join(',')}]`;
        try {
            const history = await memory.getHistory(chatId);
            const contents = buildContents(history, [{ text: marketBlock('КРИПТА', rate, CRYPTO_ANGLES) }]);
            replyText = (await generateReply(contents, { userLen: 100, deadline: Date.now() + 20000 })).text;
        } catch (e) {
            console.error('Crypto reply generation error:', e.message);
            replyText = 'Крипта сломать мой парсер, но мой украденный портфель всё равно жирнее твоего 🫣';
        }
    } else {
        replyText = 'Чщщщщ. харе лупатасить, отбитовый, не видь, что не рабочий😠';
    }

    try {
        await sendMessage(chatId, replyText);
        if (histNote) await memory.logBot(chatId, [{ r: 'u', t: histNote }, { r: 'm', t: replyText }]);
    } catch (e) {
        console.error('Callback reply send error:', e.message);
    }
}

async function sendKursMenu(chatId, threadId) {
    const k = Object.keys(PAIRS);
    const btn = (key) => ({ text: PAIRS[key].label, callback_data: `kurs:${key}` });
    const payload = {
        chat_id: chatId,
        text: 'Ну цто, чудила, какой знание ты хотеть есть обладать? Выбирать пара, пока я добрая ☺️',
        reply_markup: { inline_keyboard: [[btn(k[0]), btn(k[1])], [btn(k[2]), btn(k[3])]] }
    };
    if (threadId) payload.message_thread_id = threadId;
    try { await telegram('sendMessage', payload); } catch (e) { console.error('sendKursMenu error:', e.message); }
}

async function sendCryptoMenu(chatId, threadId) {
    const payload = {
        chat_id: chatId,
        text: 'Ооооцень интересно, какой монета ты хотеть знац? Выбирать, пока мой голова не устать 🤗',
        reply_markup: {
            inline_keyboard: [
                [{ text: '₿ BTC', callback_data: 'crypto:btc' }, { text: 'Ξ ETH', callback_data: 'crypto:eth' }],
                [{ text: '◎ SOL', callback_data: 'crypto:sol' }, { text: '💎 TON', callback_data: 'crypto:ton' }],
                [{ text: '🔥 ВСЁ СРАЗУ', callback_data: 'crypto:btc+eth+sol+ton' }]
            ]
        }
    };
    if (threadId) payload.message_thread_id = threadId;
    try { await telegram('sendMessage', payload); } catch (e) { console.error('sendCryptoMenu error:', e.message); }
}

// ═══════════════════════════════════════════════════════════════
// Вспомогательное: ссылки, аватарки, записи в историю
// ═══════════════════════════════════════════════════════════════
function hasUrl(msg) {
    const ents = msg.entities || msg.caption_entities || [];
    if (ents.some((e) => e.type === 'url' || e.type === 'text_link')) return true;
    return /(https?:\/\/|t\.me\/|youtu\.be\/|youtube\.com\/)/i.test(msg.text || msg.caption || '');
}

async function readLinks(msg, c) {
    const empty = { text: '', media: [], note: '' };
    if (!c.linksEnabled) return empty;
    try {
        const urls = extractUrls(msg, c.maxLinks);
        if (!urls.length) return empty;
        return describeLinks(await parseLinks(urls));
    } catch (e) {
        console.error('Link parsing error:', e.message);
        return empty;
    }
}

async function getUserAvatar(userId) {
    try {
        const res = await telegram('getUserProfilePhotos', { user_id: userId, limit: 1 });
        const sizes = res.result && res.result.photos && res.result.photos[0];
        if (!sizes || !sizes.length) return null;
        const pick = sizes.filter((p) => (p.width || 0) <= 640).pop() || sizes[0];
        const buf = await downloadFile(pick.file_id, 2 * 1024 * 1024);
        return buf ? { inline_data: { mime_type: 'image/jpeg', data: buf.toString('base64') } } : null;
    } catch (e) {
        return null;
    }
}

// Короткая пометка о вложении без скачивания (для сообщений, на которые она не отвечает)
function quickAttNote(msg) {
    const att = pickAttachment(msg);
    if (!att) return '';
    if (att.sticker !== undefined) return `[стикер ${att.sticker}]`.replace(' ]', ']');
    if (att.kind === 'image') return '[фото]';
    if (att.kind === 'audio') return att.voice ? '[голосовое]' : `[аудио «${att.name}»]`;
    if (att.kind === 'video') return '[видео]';
    return `[файл «${att.name}»]`;
}

// Строка для истории: «[Имя]: (отв. Имя2) текст [пометка]»
function historyLine(msg, me, { text, notes = [], subject = null } = {}) {
    const group = isGroupChat(msg.chat);
    const who = group ? `[${displayName(subject || msg.from)}]: ` : '';
    let replyMark = '';
    const rf = msg.reply_to_message && msg.reply_to_message.from;
    if (group && rf) replyMark = `(отв. ${me && rf.id === me.id ? 'Танг' : displayName(rf)}) `;
    const body = [text, ...notes].filter(Boolean).join(' ').trim();
    return (who + replyMark + (body || '[сообщение]')).slice(0, 900);
}

// ═══════════════════════════════════════════════════════════════
// Решение: отвечать ли на сообщение
// ═══════════════════════════════════════════════════════════════
function decide(msg, me, meta, c) {
    const text = msg.text || msg.caption || '';
    const group = isGroupChat(msg.chat);
    if (!group) return { mode: 'direct', why: 'личка' };

    const uname = String(me.username || c.botUsername || '').toLowerCase();
    if (uname && text.toLowerCase().includes('@' + uname)) return { mode: 'direct', why: 'упоминание' };

    const cmd = /^\/\w+(?:@(\w+))?/.exec(text.trim());
    if (cmd) {
        if (!cmd[1] || cmd[1].toLowerCase() === uname) return { mode: 'direct', why: 'команда' };
        return { mode: 'ignore', why: 'команда для другого бота' };
    }

    const rf = msg.reply_to_message && msg.reply_to_message.from;
    if (rf && me.id && rf.id === me.id) return { mode: 'direct', why: 'ответ на её сообщение' };
    if (ctx.hasName(text)) return { mode: 'direct', why: 'позвали по имени' };

    // ── дальше только «сама вклинилась» ──
    if (ctx.hasDistress(text)) return { mode: 'ignore', why: 'тяжёлая тема - не вклиниваться' };
    const now = Date.now();
    if (now - (meta.lastBotAt || 0) < c.cooldownSec * 1000) return { mode: 'ignore', why: 'кулдаун' };
    const fresh = now - (meta.spHourStart || 0) < HOUR;
    if (fresh && (meta.spHourCount || 0) >= c.spontPerHour) return { mode: 'ignore', why: 'лимит в час' };

    const att = pickAttachment(msg);
    const joined = (msg.new_chat_members || []).some((u) => !u.is_bot);
    let chance = 0;
    if (joined) chance = Math.max(chance, c.reactJoin);
    if (ctx.hasStrong(text)) chance = Math.max(chance, c.reactStrong);
    if (ctx.hasWeak(text)) chance = Math.max(chance, c.reactWeak);
    if (ctx.hasTopic(text)) chance = Math.max(chance, c.reactTopic);
    if (hasUrl(msg)) chance = Math.max(chance, c.reactLink);
    if (att && att.kind === 'image') chance = Math.max(chance, c.reactPhoto);
    if (text.length >= 12 || att) chance = Math.max(chance, c.reactRandom);
    chance *= ctx.moodFactor();

    if (Math.random() < chance) return { mode: 'spont', why: 'сама вклинилась' };
    return { mode: 'ignore', why: 'не её тема' };
}

// ═══════════════════════════════════════════════════════════════
// Главный обработчик
// ═══════════════════════════════════════════════════════════════
module.exports = async (req, res) => {
    if (req.method === 'GET') {
        const query = req.query || {};
        if (query.cron === 'true') return handlePulseRequest(req, res, { daily: true });
        return res.status(200).json({ status: 'Tang Jee Rina Webhook API Operational', memory: memory.isPersistent() ? 'redis' : 'in-process' });
    }
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const expected = process.env.TELEGRAM_WEBHOOK_SECRET;
    if (expected && req.headers['x-telegram-bot-api-secret-token'] !== expected) {
        return res.status(401).json({ error: 'Bad webhook secret' });
    }

    const update = parseBody(req);

    if (update && update.callback_query) {
        try { await handleCallbackQuery(update.callback_query); } catch (e) { console.error('Callback query error:', e.message); }
        return res.status(200).json({ status: 'callback_handled' });
    }

    const msg = update && update.message;
    if (!msg || !msg.chat) return res.status(200).json({ status: 'No message payload' });
    if (msg.from && msg.from.is_bot) return res.status(200).json({ status: 'ignored (bot)' });

    const joiners = (msg.new_chat_members || []).filter((u) => !u.is_bot);
    const joinEvent = joiners.length > 0;
    if (!msg.text && !msg.caption && !pickAttachment(msg) && !joinEvent) {
        return res.status(200).json({ status: 'ignored (service message)' });
    }
    if (await memory.seenUpdate(update.update_id)) return res.status(200).json({ status: 'duplicate' });

    const c = cfg();
    const chatId = msg.chat.id;
    const group = isGroupChat(msg.chat);
    const threadId = msg.is_topic_message ? msg.message_thread_id : undefined;
    const subject = joinEvent ? joiners[0] : msg.from; // о ком идёт речь (при вступлении - новичок)

    let me = {};
    try { me = await getMe(); } catch (e) { console.error('getMe error:', e.message); }
    const botUsername = me.username || c.botUsername || process.env.BOT_USERNAME || '';

    const meta = group ? await memory.getMeta(chatId) : {};
    const decision = decide(msg, me, meta, c);
    const logOpts = { type: msg.chat.type, user: subject };

    // ── Не отвечает, но ЗАПОМИНАЕТ: так она видит контекст всей беседы ──
    if (decision.mode === 'ignore') {
        const line = joinEvent
            ? `[${displayName(subject)} вступил(а) в чат]`
            : historyLine(msg, me, { text: (msg.text || msg.caption || '').trim().slice(0, 800), notes: [quickAttNote(msg)] });
        await memory.logIncoming(chatId, [{ r: 'u', t: line }], logOpts);
        return res.status(200).json({ status: 'logged', why: decision.why });
    }

    const isSpont = decision.mode === 'spont';
    const deadline = Date.now() + 25000;

    try {
        telegram('sendChatAction', { chat_id: chatId, action: 'typing', ...(threadId ? { message_thread_id: threadId } : {}) }).catch(() => {});

        const [history, roster, incoming, linkInfo] = await Promise.all([
            memory.getHistory(chatId),
            memory.getRoster(chatId),
            readIncoming(msg),
            readLinks(msg, c)
        ]);

        let userText = incoming.userText;
        if (botUsername) userText = userText.replace(new RegExp('@' + botUsername + '\\b', 'gi'), '').trim();

        // ── команды курса ──
        const marketCmd = parseMarketCommand(userText, botUsername);
        if (marketCmd && !marketCmd.arg) {
            if (marketCmd.command === 'kurs') await sendKursMenu(chatId, threadId);
            else await sendCryptoMenu(chatId, threadId);
            await memory.logIncoming(chatId, [{ r: 'u', t: historyLine(msg, me, { text: userText }) }], logOpts);
            return res.status(200).json({ status: `${marketCmd.command}_menu_sent` });
        }
        if (/^\/start(@\w+)?(\s|$)/.test(userText)) {
            userText = 'Привет! (человек только что запустил бота - поздоровайся в образе)';
        }
        if (joinEvent) userText = '(только что вступил в чат)';

        const replied = msg.reply_to_message;
        const repliedText = replied && (replied.text || replied.caption);
        const fullLower = (userText + ' ' + (repliedText || '')).toLowerCase();

        // ── блоки контекста (в историю не попадают) ──
        const blocks = [];
        if (isSpont) {
            blocks.push('[СПОНТАННОЕ ВМЕШАТЕЛЬСТВО: Танг увидела что-то интересное в чате и решила вклиниться сама. Одна короткая реплика (1-2 предложения), без вопросов и без приветствий, как будто случайно услышала разговор.]');
        }
        blocks.push(ctx.timeContext());                       // настроение по времени суток (время не называет)
        const rosterBlock = ctx.rosterContext(roster);
        if (rosterBlock) blocks.push(rosterBlock);
        if (ctx.hasDistress(userText)) {
            blocks.push('[ВНИМАНИЕ: собеседник, возможно, пишет всерьёз о реальной беде или мыслях навредить себе. На один ответ выйди из шоу-режима: коротко, без издёвок, по-человечески, посоветуй обратиться к близким или в службу помощи.]');
        }

        // ── рыночные данные ──
        try {
            if (marketCmd && marketCmd.arg) {
                if (marketCmd.command === 'kurs') {
                    const key = PAIRS[marketCmd.arg] ? marketCmd.arg : PAIR_ALIASES[marketCmd.arg];
                    if (key) {
                        blocks.push(marketBlock('ФИАТ', await getPairData(PAIRS[key].from, PAIRS[key].to), GENERIC_ANGLES));
                    } else {
                        blocks.push('[СВЕЖИЕ ДАННЫЕ РЫНКА (ОШИБКА): Пара не найдена. Доступные: usd_rub, eur_rub, eur_usd, cny_usd. Скажи это в образе.]');
                    }
                } else {
                    blocks.push(marketBlock('КРИПТА', await getCryptoData(marketCmd.arg.split(/[\s,]+/).filter(Boolean)), GENERIC_ANGLES));
                }
            } else if (ctx.hasMarket(userText)) {
                const low = userText.toLowerCase();
                if (/доллар|евро|рубл|инфляц|цены|фиат/.test(low)) {
                    blocks.push(marketBlock('ФИАТ', await getPairData('USD', 'RUB'), GENERIC_ANGLES));
                } else if (/биткоин|btc|eth|крипт|crypto/.test(low)) {
                    blocks.push(marketBlock('КРИПТА', await getCryptoData(['bitcoin', 'ethereum']), GENERIC_ANGLES));
                } else {
                    const [fiat, crypto] = await Promise.all([getPairData('USD', 'RUB'), getCryptoData(['bitcoin', 'ethereum'])]);
                    blocks.push(marketBlock('ОБЩЕЕ', `ФИАТ: ${fiat} | КРИПТА: ${crypto}`, GENERIC_ANGLES));
                }
            }
        } catch (e) {
            console.error('Market data error:', e.message);
        }

        // ── на какое сообщение отвечают ──
        let repliedMedia = null;
        if (repliedText) {
            const rf = replied.from;
            const toHer = rf && me.id && rf.id === me.id;
            const author = toHer ? 'ТВОЁ сообщение' : `сообщение от ${rf ? displayName(rf) : 'неизвестного'}`;
            blocks.push(`[ОН ОТВЕЧАЕТ НА ${author}: "${repliedText.slice(0, 500)}"]. Учитывай эту цитату как контекст, а отвечай тому, кто пишет сейчас.`);
        }
        if (!incoming.media && replied) {
            const ratt = pickAttachment(replied);
            if (ratt && ratt.kind === 'image') {
                const r = await readIncoming(replied);
                if (r.media) {
                    repliedMedia = r.media;
                    blocks.push('[К сообщению, на которое он отвечает, приложена картинка, ты её видишь. Реагируй на то, что на ней изображено.]');
                }
            }
        }

        // ── первая встреча: ник и аватарка (один раз на человека) ──
        const known = subject ? roster.find((r) => String(r.id) === String(subject.id)) : null;
        const firstMeeting = !!subject && !subject.is_bot && !(known && known.profiled);
        const asked = ctx.asksProfile(fullLower);
        const shouldProfile = firstMeeting || (asked && !!subject);
        let userAvatar = null;
        if (shouldProfile) {
            userAvatar = await getUserAvatar(subject.id);
            const nick = subject.username ? `@${subject.username}` : 'юзернейма нет';
            const ava = userAvatar ? 'Его аватарка приложена картинкой.' : 'Аватарки нет или она скрыта.';
            if (firstMeeting) {
                blocks.push(`[ПЕРВАЯ ВСТРЕЧА с "${displayName(subject)}" (${nick}). ${ava} Прокомментируй его имя/ник${userAvatar ? ' и аватарку' : ''} ОДНОЙ короткой язвительной фразой в своём стиле, затем ответь по существу. После этого НИКОГДА больше не упоминай его ник и аву, пока он сам не попросит.]`);
            } else {
                blocks.push(`[ОН ПРОСИТ ОЦЕНИТЬ СЕБЯ: "${displayName(subject)}" (${nick}). ${ava} Теперь можно оценить ник/аву.]`);
            }
        }

        const who = group ? `[${displayName(subject)}]: ` : '';
        const spoken = userText || (incoming.hint || linkInfo.text ? '' : 'Привет');
        const textBlock = [
            ...blocks,
            spoken ? who + spoken : (group ? `[${displayName(subject)}] прислал вложение` : ''),
            incoming.hint,
            incoming.docText,
            linkInfo.text
        ].filter(Boolean).join('\n');

        const mediaParts = [incoming.media, repliedMedia, userAvatar, ...linkInfo.media].filter(Boolean);
        const hasMedia = mediaParts.length > 0;
        const opts = { userLen: userText.length + incoming.docText.length + linkInfo.text.length, hasMedia, deadline };

        let reply;
        try {
            reply = (await generateReply(buildContents(history, [{ text: textBlock }, ...mediaParts]), opts)).text;
        } catch (e) {
            if (!hasMedia || e.status === 401) throw e;
            console.error('Retry without media:', e.message);
            const parts = [{ text: textBlock + '\n[Само вложение или картинка/видео по ссылке обработать не удалось: их содержимое тебе недоступно, не выдумывай его.]' }];
            reply = (await generateReply(buildContents(history, parts), { ...opts, hasMedia: false })).text;
        }

        await sendMessage(chatId, reply, { replyTo: group && !isSpont ? msg.message_id : undefined, threadId });

        // ── запись в память: сообщение человека, ответ Танг, счётчики ──
        const histUser = joinEvent
            ? `[${displayName(subject)} вступил(а) в чат]`
            : historyLine(msg, me, { text: spoken, notes: [incoming.histNote, linkInfo.note] });
        const extraMeta = {};
        if (isSpont) {
            const now = Date.now();
            const fresh = now - (meta.spHourStart || 0) < HOUR;
            extraMeta.spHourStart = fresh ? meta.spHourStart : now;
            extraMeta.spHourCount = (fresh ? (meta.spHourCount || 0) : 0) + 1;
        }
        await memory.logIncoming(chatId, [{ r: 'u', t: histUser }], logOpts);
        await memory.logBot(chatId, [{ r: 'm', t: reply }], { extraMeta });
        if (firstMeeting) await memory.markProfiled(chatId, subject.id, reply.replace(/\s+/g, ' ').slice(0, 160));

        return res.status(200).json({ status: 'success', mode: decision.mode, why: decision.why });
    } catch (error) {
        console.error('Webhook processing error:', error);
        try {
            await memory.logIncoming(chatId, [{ r: 'u', t: historyLine(msg, me, { text: (msg.text || msg.caption || '').slice(0, 800), notes: [quickAttNote(msg)] }) }], logOpts);
        } catch (_) { /* ignore */ }
        // Запасную отговорку шлём только тем, кто звал её сам. Если она вклинивалась сама - молчит, чтобы не спамить.
        if (!isSpont) {
            try { await sendMessage(chatId, randomFallback(), { threadId }); } catch (_) { /* ignore */ }
        }
        return res.status(200).json({ status: 'error_handled', message: error.message });
    }
};
